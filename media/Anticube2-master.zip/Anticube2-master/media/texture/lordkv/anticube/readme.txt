Most textures are modified versions of Nieb's base textures for Tesseract.
