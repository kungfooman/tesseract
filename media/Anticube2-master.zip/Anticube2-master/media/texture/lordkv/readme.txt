This directory contains files that I use in my maps. Most of these files were created by other people.
"rock01" textures are by Lunaran.
