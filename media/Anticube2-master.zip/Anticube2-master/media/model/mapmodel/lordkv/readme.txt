This directory contains files that I use in my maps. Most of these files were created by other people.
Fern model was created by Nieb and rock01 textures by Lunaran.
