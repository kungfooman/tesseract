Credits:

Frecle Tree Generator: textures.  I believe free use is permitted as long as you are not profiting from the textures.

Bark texture: http://seamless-pixels.blogspot.cz/2014/07/wood-tree-bark-seamless-texture.html
(bark texture and normal maps added by Kv for the map Anticube 2. Please credit seamless-pixels site for the bark texture)